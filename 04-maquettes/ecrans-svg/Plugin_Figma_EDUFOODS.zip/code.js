// EDUFOODS – plugin Figma : variables couleur + prototype
const TOKENS = [
  [
    "Marque/Principal",
    "#2BB673"
  ],
  [
    "Marque/Principal foncé",
    "#1E8E57"
  ],
  [
    "Marque/Principal clair",
    "#E3F6EC"
  ],
  [
    "Marque/Accent",
    "#FF8A3D"
  ],
  [
    "Marque/Accent clair",
    "#FFEEDF"
  ],
  [
    "Neutres/Texte",
    "#1E2A38"
  ],
  [
    "Neutres/Texte secondaire",
    "#6B7785"
  ],
  [
    "Neutres/Bordure",
    "#E4E8E6"
  ],
  [
    "Neutres/Fond",
    "#F7F9F6"
  ],
  [
    "Neutres/Surface",
    "#FFFFFF"
  ],
  [
    "États/Alerte",
    "#E5484D"
  ],
  [
    "États/Alerte clair",
    "#FDE8E8"
  ]
];
const SIZES = {"01": [390, 844], "02": [390, 844], "03": [390, 844], "04": [390, 844], "05": [390, 844], "06": [390, 844], "07": [390, 844], "08": [390, 844], "09": [1440, 900], "10": [1440, 900], "11": [1440, 900], "12": [1440, 900], "13": [1440, 900], "14": [1440, 2360]};
const LINKS = [{"f": "01", "x": 20, "y": 494, "w": 350, "h": 236, "to": "02", "label": "Carte Green Bowl"}, {"f": "01", "x": 258, "y": 388, "w": 96, "h": 36, "to": "03", "label": "Rejoindre le groupe"}, {"f": "01", "x": 195.0, "y": 758, "w": 97.5, "h": 86, "to": "05", "label": "Onglet Commandes"}, {"f": "01", "x": 292.5, "y": 758, "w": 97.5, "h": 86, "to": "06", "label": "Onglet Profil"}, {"f": "02", "x": 20, "y": 56, "w": 44, "h": 44, "to": "BACK", "label": "Retour"}, {"f": "02", "x": 20, "y": 760, "w": 350, "h": 56, "to": "03", "label": "Voir le panier groupé"}, {"f": "03", "x": 20, "y": 60, "w": 44, "h": 44, "to": "BACK", "label": "Retour"}, {"f": "03", "x": 20, "y": 758, "w": 350, "h": 54, "to": "04", "label": "Payer"}, {"f": "04", "x": 20, "y": 60, "w": 44, "h": 44, "to": "BACK", "label": "Retour"}, {"f": "04", "x": 20, "y": 752, "w": 350, "h": 54, "to": "05", "label": "Confirmer et payer"}, {"f": "05", "x": 20, "y": 56, "w": 44, "h": 44, "to": "01", "label": "Retour à l'accueil"}, {"f": "06", "x": 0, "y": 758, "w": 97.5, "h": 86, "to": "01", "label": "Onglet Accueil"}, {"f": "06", "x": 195.0, "y": 758, "w": 97.5, "h": 86, "to": "05", "label": "Onglet Commandes"}, {"f": "06", "x": 20, "y": 362, "w": 350, "h": 56, "to": "05", "label": "Mes commandes"}, {"f": "07", "x": 250, "y": 390, "w": 104, "h": 38, "to": "08", "label": "Accepter la course"}, {"f": "08", "x": 20, "y": 56, "w": 44, "h": 44, "to": "BACK", "label": "Retour"}, {"f": "08", "x": 20, "y": 778, "w": 350, "h": 50, "to": "07", "label": "Confirmer la livraison"}, {"f": "09", "x": 40, "y": 22, "w": 170, "h": 36, "to": "14", "label": "Logo → site vitrine"}, {"f": "09", "x": 332, "y": 236, "w": 246, "h": 236, "to": "02", "label": "Carte Green Bowl"}, {"f": "09", "x": 1216, "y": 18, "w": 120, "h": 40, "to": "03", "label": "Panier"}, {"f": "09", "x": 1290, "y": 252, "w": 82, "h": 28, "to": "03", "label": "Rejoindre Poké Campus"}, {"f": "10", "x": 14, "y": 204, "w": 220, "h": 40, "to": "11", "label": "Menu"}, {"f": "10", "x": 14, "y": 252, "w": 220, "h": 40, "to": "11", "label": "Offres de gros"}, {"f": "11", "x": 14, "y": 108, "w": 220, "h": 40, "to": "10", "label": "Tableau de bord"}, {"f": "12", "x": 14, "y": 156, "w": 220, "h": 40, "to": "13", "label": "Restaurants"}, {"f": "12", "x": 14, "y": 204, "w": 220, "h": 40, "to": "13", "label": "Utilisateurs"}, {"f": "13", "x": 14, "y": 108, "w": 220, "h": 40, "to": "12", "label": "Tableau de bord"}, {"f": "14", "x": 1240, "y": 26, "w": 120, "h": 44, "to": "09", "label": "Commander (menu)"}, {"f": "14", "x": 80, "y": 530, "w": 230, "h": 58, "to": "09", "label": "Commander maintenant"}, {"f": "14", "x": 326, "y": 530, "w": 210, "h": 58, "to": "09", "label": "Voir les restaurants"}, {"f": "14", "x": 120, "y": 1826, "w": 210, "h": 46, "to": "10", "label": "Devenir partenaire"}, {"f": "14", "x": 776, "y": 1826, "w": 210, "h": 46, "to": "07", "label": "Rejoindre l'équipe"}];
const FLOWS = [["01", "Parcours étudiant (mobile)"], ["07", "Parcours chauffeur"], ["10", "Espace restaurant"], ["12", "Back-office"], ["14", "Site vitrine"]];
const HOTSPOT_PREFIX = "↪ ";

function hexToRgb(hex) {
  const n = parseInt(hex.slice(1), 16);
  return { r: ((n >> 16) & 255) / 255, g: ((n >> 8) & 255) / 255, b: (n & 255) / 255 };
}
function toHex(c) {
  return "#" + [c.r, c.g, c.b].map(v => Math.round(v * 255).toString(16).padStart(2, "0")).join("").toUpperCase();
}

// ---------- 1. Variables couleur ----------
async function variables() {
  const collections = await figma.variables.getLocalVariableCollectionsAsync();
  let coll = collections.find(c => c.name === "EDUFOODS");
  if (!coll) coll = figma.variables.createVariableCollection("EDUFOODS");
  const modeId = coll.modes[0].modeId;
  coll.renameMode(modeId, "Clair");
  const existing = await figma.variables.getLocalVariablesAsync("COLOR");
  const byHex = {};
  for (const [name, hex] of TOKENS) {
    let v = existing.find(x => x.name === name && x.variableCollectionId === coll.id);
    if (!v) { v = figma.variables.createVariable(name, coll, "COLOR"); v.setValueForMode(modeId, hexToRgb(hex)); }
    byHex[hex.toUpperCase()] = v;
  }
  let count = 0;
  function bind(node, prop) {
    if (!(prop in node)) return;
    const paints = node[prop];
    if (paints === figma.mixed || !Array.isArray(paints) || paints.length === 0) return;
    let changed = false;
    const next = paints.map(p => {
      if (p.type !== "SOLID" || (p.boundVariables && p.boundVariables.color)) return p;
      const v = byHex[toHex(p.color)];
      if (!v) return p;
      changed = true; count++;
      return figma.variables.setBoundVariableForPaint(p, "color", v);
    });
    if (changed) node[prop] = next;
  }
  function walk(node) {
    if (node.name && node.name.startsWith(HOTSPOT_PREFIX)) return;
    bind(node, "fills"); bind(node, "strokes");
    if ("children" in node) for (const child of node.children) walk(child);
  }
  const roots = figma.currentPage.selection.length ? figma.currentPage.selection : figma.currentPage.children;
  for (const r of roots) walk(r);
  return `${TOKENS.length} variables, ${count} couleurs reliées`;
}

// ---------- 2. Prototype ----------
function findFrames() {
  const frames = {};
  for (const node of figma.currentPage.children) {
    if (node.type !== "FRAME" && node.type !== "GROUP" && node.type !== "COMPONENT") continue;
    const m = node.name.match(/^(\d{2})(?:[_ .-]|$)/);
    if (m && SIZES[m[1]] && !frames[m[1]]) frames[m[1]] = node;
  }
  return frames;
}
function asFrame(node) {
  // un SVG importé est normalement un frame ; si c'est un groupe, on l'enveloppe dans un frame
  if (node.type === "FRAME" || node.type === "COMPONENT") return node;
  const parent = node.parent, index = parent.children.indexOf(node);
  const f = figma.createFrame();
  f.name = node.name; f.x = node.x; f.y = node.y;
  f.resizeWithoutConstraints(node.width, node.height); f.fills = [];
  parent.insertChild(index, f);
  f.appendChild(node); node.x = 0; node.y = 0;
  return f;
}
async function prototype() {
  const found = findFrames();
  const missing = Object.keys(SIZES).filter(k => !found[k]);
  const frames = {};
  for (const k of Object.keys(found)) frames[k] = asFrame(found[k]);

  // nettoyage des anciens liens créés par le plugin
  for (const f of Object.values(frames))
    for (const c of [...f.children]) if (c.name.startsWith(HOTSPOT_PREFIX)) c.remove();

  let made = 0;
  for (const l of LINKS) {
    const f = frames[l.f];
    if (!f) continue;
    if (l.to !== "BACK" && !frames[l.to]) continue;
    const [w0, h0] = SIZES[l.f];
    const sx = f.width / w0, sy = (l.f === "14" && f.height < h0) ? sx : f.height / h0;
    const r = figma.createRectangle();
    r.name = HOTSPOT_PREFIX + l.label;
    r.fills = []; r.strokes = [];
    r.x = l.x * sx; r.y = l.y * sy;
    r.resize(Math.max(1, l.w * sx), Math.max(1, l.h * sy));
    f.appendChild(r);
    const action = l.to === "BACK"
      ? { type: "BACK" }
      : { type: "NODE", destinationId: frames[l.to].id, navigation: "NAVIGATE",
          transition: { type: "DISSOLVE", duration: 0.25, easing: { type: "EASE_OUT" } },
          preserveScrollPosition: false };
    await r.setReactionsAsync([{ trigger: { type: "ON_CLICK" }, actions: [action] }]);
    made++;
  }

  // site vitrine : écran de 900 px de haut avec défilement vertical
  const v = frames["14"];
  if (v && v.height > 1000) {
    v.clipsContent = true;
    v.resizeWithoutConstraints(v.width, v.width * 900 / 1440);
    v.overflowDirection = "VERTICAL";
  }

  // parcours de démarrage
  figma.currentPage.flowStartingPoints = FLOWS
    .filter(([k]) => frames[k])
    .map(([k, name]) => ({ nodeId: frames[k].id, name }));

  let msg = `${made} liens, ${figma.currentPage.flowStartingPoints.length} parcours`;
  if (missing.length) msg += ` · écrans introuvables : ${missing.join(", ")}`;
  return msg;
}

async function run() {
  const cmd = figma.command || "tout";
  const out = [];
  if (cmd === "variables" || cmd === "tout") out.push(await variables());
  if (cmd === "prototype" || cmd === "tout") out.push(await prototype());
  figma.closePlugin("✅ " + out.join(" · "));
}
run().catch(e => figma.closePlugin("Erreur : " + e.message));
